// const http = require("http");

const express = require('express');
const bodyParser = require('body-parser');
// const db = require("./server");
const feedRoutes = require('./routes/feed');
// const routes = require("./routes"); //custom imports
const app = express();

// db.getConnection().then(res => {
//     console.log(res)}
//     ).catch();
app.use(bodyParser.json());
app.use('/feed',feedRoutes);
// const server = http.createServer(app);

// const server = http.createServer(routes);
// const server = http.createServer((req,res) => {
//     // console.log(req);
//     // process.exit();
//     // const url = req.url;
//     // const method = req.method;
    

// });
// app.listen(3000);
app.listen(8080);