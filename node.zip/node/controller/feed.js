const pool = require('../server');

exports.getPosts = (req,res,next) => {
    res.status(200).json({
        posts: [{title:'first post',content:'my first post'}]
    });
};

exports.postPosts = (req,res,next) => {
    const title = req.body.title;
    const content = req.body.content;
    res.status(201).json({
        message: 'post created successfully',
        post: {id: Math.random().toString(36).slice(2),title: title,content: content}
    })
}

// exports.postPosts = (request, response,next) => {
//     pool.query('INSERT INTO users SET ?', request.body, (error, result) => {
//                 if (error) throw error;
         
//                 response.status(201).send(`User added with ID: ${result.insertId}`);
//             });
// }

exports.createUser = (request, response,next) => {
    const first_name = request.body.first_name;
    const last_name = request.body.last_name;
    const email = request.body.email;
    const phone = request.body.phone;
    const user_createdAt = new Date();
    const user_updatedAt = new Date();
    const post_id = request.body.post_id;
    response.status(201).send({
                message: 'post created successfully',
                post: {user_id: Math.random().toString(36).slice(2),
                        first_name: first_name,
                        last_name: last_name,
                        email: email,
                        phone: phone,
                        user_createdAt: user_createdAt,
                        user_updatedAt: user_updatedAt,
                        post_id: post_id
                }   
            });
}

// app.post('/users', (request, response) => {
//     pool.query('INSERT INTO users SET ?', request.body, (error, result) => {
//         if (error) throw error;
 
//         response.status(201).send(`User added with ID: ${result.insertId}`);
//     });
// });