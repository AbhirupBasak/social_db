const fs = require("fs");

const requestHandler = (req,res) => {
    const url = req.url;
    const method = req.method;
    if(url === '/'){
        res.write('<html>');
        res.write('<head><title>enter your messege</title></head>');
        res.write('<body><form action = "/messege" method = "POST"><input type = "text" name = "messege"><button type = "submit">SEND</button></form></body>');
        res.write('</html>');
        return res.end();
    }
    
    if(url === '/messege' && method === 'POST'){
        const body = [];
        req.on("data", (chunk) => {
            // console.log(chunk);
            body.push(chunk);
        });
        req.on("end", () => {
            const persedBody = Buffer.concat(body).toString();
            // console.log(persedBody);
            const messege = persedBody.split("=")[1];
            // console.log(messege);
            fs.writeFile('messege.txt', messege, (err) => {
                res.statusCode = 302;
                res.setHeader('Location','/');
                return res.end();
                
            });
            
        });
    }
};

module.exports = requestHandler;  //module export
