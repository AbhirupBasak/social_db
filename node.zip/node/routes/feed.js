const express = require('express');



const feedController = require('../controller/feed');
const router = express.Router();

router.get('/getposts',feedController.getPosts);
router.get('/getusers',feedController.getUsers);
router.post('/addpost',feedController.postPosts);
router.post('/createuser',feedController.createUser);
// router.post('/createuser',feedController.postUser);

module.exports = router;