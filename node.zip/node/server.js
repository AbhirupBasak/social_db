// const express = require("express");
const mysql = require("mysql2");

const pool = mysql.createPool({
    host : 'localhost',
    user     : 'root',
    password : 'password',
    database : 'social',
});

module.exports = pool.promise();